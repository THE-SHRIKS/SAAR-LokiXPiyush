declare module "*.asset.json" {
  const asset: {
    version: number;
    asset_id: string;
    project_id: string;
    url: string;
    r2_key: string;
  };
  export default asset;
}
