/**
 * Shared site constants. Every external link points to a verified official
 * resource: the SAAR desktop repository owned by THE SHRIKS on GitHub.
 */

export const REPO_URL = "https://github.com/THE-SHRIKS/SAAR-LokiXPiyush";
export const REPO_ISSUES_URL = "https://github.com/THE-SHRIKS/SAAR-LokiXPiyush/issues";
export const ORG_URL = "https://github.com/THE-SHRIKS";
export const APP_VERSION = "v0.1.0";

export const NAV = [
  { label: "Home", to: "/" },
  { label: "Product", to: "/product" },
  { label: "Solutions", to: "/solutions" },
  { label: "How It Works", to: "/how-it-works" },
  { label: "Contact", to: "/contact" },
] as const;

/** Verified engineering facts, from the project's quality-gate ledger (G0–G7). */
export const FACTS = [
  { term: "Zero cloud egress", detail: "connect-src 'none' — verified 0 WAN packets, 0 DNS lookups" },
  { term: "Exact money math", detail: "signed 64-bit minor units — never floating point" },
  { term: "Encrypted vaults", detail: "AES-256-GCM archives · Argon2id key derivation" },
  { term: "Local AI", detail: "Qwen2.5-3B via llama.cpp, running on your CPU" },
] as const;
