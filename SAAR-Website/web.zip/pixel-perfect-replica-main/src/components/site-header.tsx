import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { NAV } from "@/data/site";
import { GetSaar, Wordmark } from "@/components/actions";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-50 border-b border-ink/12 bg-paper/92 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-[76rem] items-center justify-between px-5 md:px-8">
        <Link to="/" aria-label="SAAR — home" className="shrink-0">
          <Wordmark />
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
          {NAV.map((item) => {
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "link-rule text-[13px] font-medium tracking-[0.02em]",
                  active ? "text-navy" : "text-ink hover:text-navy",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-3">
          <GetSaar label="Get SAAR" className="hidden md:inline-flex" />
          <button
            type="button"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-ink/15 text-ink lg:hidden"
          >
            {open ? <X className="h-4 w-4" aria-hidden="true" /> : <Menu className="h-4 w-4" aria-hidden="true" />}
            <span className="sr-only">Toggle navigation</span>
          </button>
        </div>
      </div>

      {open ? (
        <nav id="mobile-nav" aria-label="Primary, mobile" className="border-t border-ink/10 bg-paper px-5 py-4 lg:hidden">
          <ul className="flex flex-col">
            {NAV.map((item) => (
              <li key={item.to} className="border-b border-ink/8 last:border-b-0">
                <Link
                  to={item.to}
                  className="block py-3 font-display text-2xl text-ink transition-colors hover:text-navy"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <GetSaar className="mt-4 w-full justify-center md:hidden" />
        </nav>
      ) : null}
    </header>
  );
}
