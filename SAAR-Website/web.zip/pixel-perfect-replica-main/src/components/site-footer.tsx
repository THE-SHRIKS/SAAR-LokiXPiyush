import { Link } from "@tanstack/react-router";
import { NAV, REPO_URL, APP_VERSION } from "@/data/site";
import { Wordmark } from "@/components/actions";

export function SiteFooter() {
  return (
    <footer className="bg-navy text-paper">
      <div className="mx-auto max-w-[76rem] px-5 pt-16 pb-10 md:px-8">
        <div className="flex flex-col gap-12 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <Wordmark tone="paper" />
            <p className="mt-5 max-w-[38ch] text-sm leading-relaxed text-paper/70">
              Offline financial intelligence and deterministic reconciliation for Windows —
              engineered so your records never leave your machine.
            </p>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-x-12 gap-y-2 sm:grid-cols-3">
            <div>
              <p className="eyebrow text-paper/50">Site</p>
              <ul className="mt-4 space-y-2.5">
                {NAV.map((item) => (
                  <li key={item.to}>
                    <Link to={item.to} className="text-sm text-paper/80 transition-colors hover:text-paper">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="eyebrow text-paper/50">Official</p>
              <ul className="mt-4 space-y-2.5">
                <li>
                  <a href={REPO_URL} target="_blank" rel="noreferrer" className="text-sm text-paper/80 transition-colors hover:text-paper">
                    SAAR repository
                  </a>
                </li>
                <li>
                  <a href={`${REPO_URL}/blob/main/RELEASE_NOTES.md`} target="_blank" rel="noreferrer" className="text-sm text-paper/80 transition-colors hover:text-paper">
                    Release notes
                  </a>
                </li>
                <li>
                  <Link to="/contact" className="text-sm text-paper/80 transition-colors hover:text-paper">
                    Contact THE SHRIKS
                  </Link>
                </li>
              </ul>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <p className="eyebrow text-paper/50">Built by</p>
              <p className="mt-4 text-sm text-paper/80">THE SHRIKS</p>
              <p className="mt-1 text-sm text-paper/60">SAAR {APP_VERSION} · MIT / Apache-2.0</p>
            </div>
          </nav>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-paper/15 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="data-mono text-[11px] text-paper/50">© 2026 THE SHRIKS. All rights reserved.</p>
          <p className="data-mono text-[11px] text-paper/50">No telemetry · No cookies · No cloud calls</p>
        </div>
      </div>
    </footer>
  );
}
