import { createFileRoute, Link } from "@tanstack/react-router";
import { GetSaar, TextLink } from "@/components/actions";
import { AppFrame } from "@/components/app-frame";
import { Annotation, Copy, Eyebrow, SectionTitle } from "@/components/editorial";
import { REPO_URL } from "@/data/site";

import shotUnlock from "@/assets/light_01_unlock.asset.json";
import shotDocuments from "@/assets/light_04_documents_archive.asset.json";
import shotRecon from "@/assets/light_05_reconciliation_review.asset.json";
import shotChat from "@/assets/light_02_chat_seed_report.asset.json";
import shotDarkEvidence from "@/assets/dark_04_evidence_inspector.asset.json";
import shotReports from "@/assets/light_06_financial_reports.asset.json";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      {
        title: "How SAAR Works — From Install to Evidence",
        description:
          "The actual SAAR workflow in ten stages: install, unlock an encrypted workspace, import documents, review extraction, compute, reconcile, ask, inspect evidence, report, and back up.",
      },
      { property: "og:title", content: "How SAAR Works — From Install to Evidence" },
      {
        property: "og:description",
        content:
          "Ten stages of a real financial workflow in SAAR — with the honest caveats a serious product deserves.",
      },
    ],
  }),
  component: HowItWorks,
});

const STAGES = [
  { id: "stage-01", n: "01", title: "Obtain & install" },
  { id: "stage-02", n: "02", title: "Create & unlock a workspace" },
  { id: "stage-03", n: "03", title: "Import financial documents" },
  { id: "stage-04", n: "04", title: "Extract & review" },
  { id: "stage-05", n: "05", title: "Understand financial activity" },
  { id: "stage-06", n: "06", title: "Reconcile & review anomalies" },
  { id: "stage-07", n: "07", title: "Ask financial questions" },
  { id: "stage-08", n: "08", title: "Inspect the evidence" },
  { id: "stage-09", n: "09", title: "Generate reports" },
  { id: "stage-10", n: "10", title: "Secure, back up, return" },
] as const;

const FAQ = [
  {
    q: "Does SAAR require an internet connection for normal use?",
    a: "No. SAAR is built to operate fully offline. Its browser layer is compiled with outbound connections disabled (connect-src 'none'), and the project's egress audit verifies 0 WAN packets and 0 DNS lookups in a disconnected namespace. You need a connection only to obtain the application itself.",
  },
  {
    q: "Which operating system does SAAR support?",
    a: "Windows. SAAR is a native Windows desktop application built on Tauri 2, with offline NSIS/WiX installer configuration verified at quality gate G7. No macOS, Linux, Android or iOS versions are offered.",
  },
  {
    q: "What document types can be imported?",
    a: "Digital PDF invoices and receipts, scanned documents and receipt images (processed by local OCR), and bank statement CSVs (RFC 4180), within the file and page limits shown in the application's ingestion interface.",
  },
  {
    q: "Does SAAR upload financial documents to a cloud AI service?",
    a: "No. SAAR bundles a quantized Qwen2.5-3B-Instruct model that runs locally on your CPU via llama.cpp. There are no AI API calls, no accounts and no telemetry.",
  },
  {
    q: "How are financial totals calculated?",
    a: "By deterministic Rust operations using signed 64-bit minor currency units — never floating-point math, and never arithmetic performed by the language model. Currency distinctions are preserved; figures are never blended across currencies without valid conversion data.",
  },
  {
    q: "Can users review uncertain extracted information?",
    a: "Yes. Extraction is review-oriented: uncertain fields remain visible and editable, and corrections are captured in the immutable audit trail.",
  },
  {
    q: "Does SAAR automatically approve financial changes?",
    a: "No. Reconciliation links, category assignments and other material mutations require your approval, and each decision is recorded with before/after states and timestamps.",
  },
  {
    q: "Is SAAR a replacement for accounting software or professional advice?",
    a: "No. SAAR is a private financial workspace for organizing and understanding your records. It is not a certified accounting platform and does not replace professional accountants or advice.",
  },
  {
    q: "What hardware is required for local AI?",
    a: "A modern x86-64 CPU with AVX2 support — the verified baseline for the bundled llama.cpp runtime and the quantized 3B model. The model runs on CPU; no GPU is required.",
  },
  {
    q: "How can users obtain the application?",
    a: "Through the official repository at github.com/THE-SHRIKS/SAAR-LokiXPiyush, which includes a step-by-step Windows build guide. Public installer publishing is being prepared; this page will link it the moment it exists.",
  },
] as const;

function HowItWorks() {
  return (
    <>
      {/* Opening */}
      <section className="border-b border-ink/12">
        <div className="mx-auto max-w-[76rem] px-5 pt-16 pb-14 md:px-8 md:pt-24 md:pb-20">
          <Eyebrow>How it works</Eyebrow>
          <h1 className="mt-6 max-w-[16ch] font-display text-[2.75rem] leading-[1.05] tracking-[-0.015em] text-ink sm:text-6xl md:text-[4.4rem]">
            From installer to evidence, in ten stages.
          </h1>
          <Copy className="mt-8 max-w-[64ch]">
            This is the actual SAAR workflow — not “upload, analyze, succeed.” Each stage below
            describes what you do, what the application does, and where honest uncertainty lives.
            All interface views shown are the real application, from the official repository.
          </Copy>
        </div>
      </section>

      {/* Stage index + stages */}
      <div className="mx-auto max-w-[76rem] px-5 py-16 md:px-8 md:py-20">
        <div className="grid gap-14 lg:grid-cols-[15rem_1fr]">
          <nav aria-label="Workflow stages" className="hidden lg:block">
            <ol className="sticky top-24 space-y-1 border-l border-ink/12 pl-4">
              {STAGES.map((s) => (
                <li key={s.id}>
                  <a
                    href={`#${s.id}`}
                    className="group flex items-baseline gap-3 py-1.5 text-[13px] text-ink-soft transition-colors hover:text-navy"
                  >
                    <span className="data-mono text-[10px] text-navy/70 group-hover:text-navy">{s.n}</span>
                    {s.title}
                  </a>
                </li>
              ))}
            </ol>
          </nav>

          <div className="space-y-16 md:space-y-24">
            <Stage id="stage-01" n="01" title="Obtain & install">
              <Copy>
                SAAR is a native Windows desktop application. The installed application runs
                locally: no cloud account, no development server, no sign-up. Installer
                configuration (NSIS/WiX) and the Windows build pipeline have passed the project's
                release verification gate.
              </Copy>
              <Copy className="mt-4">
                <span className="font-medium text-ink">Status note:</span> public installer
                publishing is being prepared. For now, the official repository carries the source
                code and a step-by-step Windows build guide — and that repository is the only
                download source this website links to.
              </Copy>
              <a
                href={REPO_URL}
                target="_blank"
                rel="noreferrer"
                className="link-rule mt-5 inline-block text-sm font-medium text-navy"
              >
                Open the official repository →
              </a>
            </Stage>

            <Stage id="stage-02" n="02" title="Create & unlock a workspace">
              <Copy>
                Your financial life in SAAR lives inside a workspace: a name, a base currency and
                a master passphrase of your choosing. The passphrase derives encryption keys via
                Argon2id (64 MiB, 3 passes); the workspace database and documents are stored
                encrypted (SQLCipher / AES-256-GCM), isolated per workspace. Locking wipes derived
                keys from memory; unlocking restores them — from a passphrase only you hold.
              </Copy>
              <Copy className="mt-4">
                Workspaces are independent containers: separate clients, side projects or
                companies can live side by side without sharing a byte.
              </Copy>
              <StageFigure
                className="mt-8"
                src={shotUnlock.url}
                alt="SAAR's workspace unlock screen"
                caption="The unlock screen. Cryptography details are shown in the interface itself, in plain view."
              />
            </Stage>

            <Stage id="stage-03" n="03" title="Import financial documents">
              <Copy>
                Select the local files you want in the workspace: digital invoice and receipt
                PDFs, scanned documents and receipt images, and bank statement CSVs. Each import
                is validated and fingerprinted with SHA-256 — the same file brought in twice is
                recognized, not silently duplicated — and stored in the encrypted, content-addressed
                vault.
              </Copy>
              <StageFigure
                className="mt-8"
                src={shotDocuments.url}
                alt="SAAR's ingestion pipeline and document repository"
                caption="The air-gapped ingestion pipeline and the resulting document repository, with fingerprints and import timestamps."
              />
            </Stage>

            <Stage id="stage-04" n="04" title="Extract & review">
              <Copy>
                Digital text is read directly; scanned documents go through local RapidOCR models
                (DBNet + SVTR), with bounding boxes you can inspect. SAAR extracts merchants,
                dates, invoice numbers, currencies, totals and payment references into structured
                records.
              </Copy>
              <Copy className="mt-4">
                What extraction never claims: perfection. Uncertain fields stay visible and
                editable, your corrections are audited, and the original document remains one
                click away for comparison.
              </Copy>
            </Stage>

            <Stage id="stage-05" n="05" title="Understand financial activity">
              <Copy>
                With structured records in place, the deterministic engine answers the steady
                questions: spending totals, income, net cash flow, merchant summaries, period
                comparisons. Every figure is computed in exact minor units by the Rust core —
                which is why the numbers are reproducible and the math doesn't drift.
              </Copy>
            </Stage>

            <Stage id="stage-06" n="06" title="Reconcile & review anomalies">
              <Copy>
                Run reconciliation across invoices and transactions. Deterministic multi-pass
                matching proposes links using amount, vendor tokens, currency, references and date
                tolerance; anomalies — suspected duplicates, unlinked large debits, mismatches —
                are surfaced as candidates for investigation.
              </Copy>
              <Copy className="mt-4">
                The distinction that matters: a proposed match is a hypothesis awaiting your
                approval, and a missing transaction in an export is not proof of anything. You
                decide; SAAR records the decision.
              </Copy>
              <StageFigure
                className="mt-8"
                src={shotRecon.url}
                alt="SAAR's reconciliation inbox with anomalies and candidate proposals"
                caption="Reconciliation inbox: anomalies on top, candidate link proposals below, your approvals recorded in the audit trail."
              />
            </Stage>

            <Stage id="stage-07" n="07" title="Ask financial questions">
              <Copy>
                Ask in plain language — “What is our net operating surplus?”, “Which invoices have
                no confirmed match?”, “What changed between two periods?”. The local model resolves
                your question to an authorized financial operation; the core computes the result;
                the assistant explains it, grounded in retrieved records with formal citation
                syntax and anti-hallucination checks.
              </Copy>
              <StageFigure
                className="mt-8"
                src={shotChat.url}
                alt="A grounded answer in SAAR's conversation workspace"
                caption="A grounded answer, stating its grounding: local SQLite ledger, local CPU inference."
              />
            </Stage>

            <Stage id="stage-08" n="08" title="Inspect the evidence">
              <Copy>
                This is where trust is earned. Open the evidence inspector beside any answer and
                trace the figure to the records, extracted fields and calculation that produced it
                — citations pointing at real invoice and transaction identifiers, overlays
                anchoring text back to the scanned page.
              </Copy>
              <StageFigure
                className="mt-8"
                src={shotDarkEvidence.url}
                alt="SAAR's contextual evidence inspector beside the conversation"
                caption="Evidence and answer share one screen. Nothing is asked to be taken on faith."
              />
            </Stage>

            <Stage id="stage-09" n="09" title="Generate reports">
              <Copy>
                Produce a financial summary for the period you choose: reporting period, currency,
                covered records, calculated figures, sources — and outstanding exceptions, if any
                remain unreviewed. Export as a source-traceable vector PDF or an RFC 4180 CSV,
                written by pure-Rust exporters inside the app.
              </Copy>
              <StageFigure
                className="mt-8"
                src={shotReports.url}
                alt="SAAR's deterministic financial reports view"
                caption="Deterministic reports: totals, trend, ledger breakdown and export actions."
              />
            </Stage>

            <Stage id="stage-10" n="10" title="Secure, back up, return">
              <Copy>
                Lock the workspace when you step away — keys leave memory. Back up to an
                authenticated .saar archive (AES-256-GCM over the database and documents), and
                restore it on the same or another machine. The workspace reopens exactly where
                your records left off.
              </Copy>
              <Copy className="mt-4">
                <span className="font-medium text-ink">Status note:</span> backup and restore are
                implemented and covered by the project's reliability gate (G6); encrypted-recovery
                edge cases remain part of ongoing end-to-end verification.
              </Copy>
            </Stage>
          </div>
        </div>
      </div>

      {/* Worked example */}
      <section className="border-t border-ink/12 bg-stone/45 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <Eyebrow tone="muted">One complete example</Eyebrow>
          <SectionTitle className="mt-5" size="sm">
            A month in the life of a consultant's ledger.
          </SectionTitle>
          <Annotation className="mt-4">Illustrative scenario with synthetic figures</Annotation>
          <div className="mt-10 grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 md:grid-cols-3">
            {[
              ["Monday", "Priya, an independent consultant, imports September's client invoices (PDF), a stack of expense receipts (scans), and her bank's CSV export. Extraction flags two uncertain merchant names; she corrects them in two minutes."],
              ["Wednesday", "She runs reconciliation. Two invoices match their payments exactly; one payment to a vendor has no matching invoice — SAAR raises it as an unlinked large debit. She checks the vendor's site, finds the missing invoice, imports it, and approves the link."],
              ["Friday", "She asks for September's expense summary and net cash flow, opens the evidence behind the largest figure to confirm the receipt, and exports a source-traceable PDF for her accountant — her records never having left her laptop."],
            ].map(([day, text]) => (
              <div key={day} className="bg-paper p-6 md:p-8">
                <Annotation className="text-navy">{day}</Annotation>
                <p className="mt-3 text-sm leading-relaxed text-ink-soft">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <Eyebrow>Questions</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                Asked, and answered precisely.
              </SectionTitle>
              <Copy className="mt-5">
                Answers reflect the project's verified quality gates and specifications. Where a
                requirement isn't confirmed, the answer says so instead of guessing.
              </Copy>
            </div>
            <div className="lg:col-span-8">
              <div className="divide-y divide-ink/10 border-y border-ink/10">
                {FAQ.map((item, i) => (
                  <details key={item.q} className="group py-5" open={i === 0}>
                    <summary className="flex cursor-pointer list-none items-start justify-between gap-6 [&::-webkit-details-marker]:hidden">
                      <span className="font-display text-xl leading-snug text-ink md:text-2xl">{item.q}</span>
                      <span
                        aria-hidden="true"
                        className="data-mono mt-1 shrink-0 text-navy transition-transform duration-300 group-open:rotate-45"
                      >
                        +
                      </span>
                    </summary>
                    <p className="mt-4 max-w-[70ch] text-sm leading-relaxed text-ink-soft">{item.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-ink/12 bg-navy text-paper">
        <div className="mx-auto max-w-[76rem] px-5 py-16 md:px-8 md:py-20">
          <div className="grid gap-8 md:grid-cols-12 md:items-center">
            <h2 className="font-display text-3xl leading-tight md:col-span-7 md:text-4xl">
              Ten stages. One afternoon to try them all.
            </h2>
            <div className="md:col-span-5 md:text-right">
              <GetSaar variant="onNavy" size="lg" className="md:ml-auto" />
              <p className="mt-3 text-xs text-paper/60">
                Or{" "}
                <Link to="/contact" className="underline decoration-paper/40 hover:text-paper">
                  contact THE SHRIKS
                </Link>{" "}
                with a question first.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Stage({
  id,
  n,
  title,
  children,
}: {
  id: string;
  n: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} aria-labelledby={`${id}-title`} className="scroll-mt-24">
      <div className="flex items-baseline gap-4">
        <span className="data-mono text-sm font-medium text-navy">{n}</span>
        <span aria-hidden="true" className="h-px flex-1 bg-ink/12" />
        <Annotation>stage</Annotation>
      </div>
      <h2 id={`${id}-title`} className="mt-5 font-display text-3xl leading-tight text-ink md:text-4xl">
        {title}
      </h2>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function StageFigure({
  src,
  alt,
  caption,
  className,
}: {
  src: string;
  alt: string;
  caption: string;
  className?: string;
}) {
  return (
    <AppFrame src={src} alt={alt} caption={caption} className={className} />
  );
}

{
  /* keep TextLink referenced for future stage links */
}
void TextLink;
