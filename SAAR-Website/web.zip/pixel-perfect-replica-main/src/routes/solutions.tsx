import { createFileRoute, Link } from "@tanstack/react-router";
import { GetSaar, TextLink } from "@/components/actions";
import { Annotation, Copy, Eyebrow, SectionTitle } from "@/components/editorial";
import { REPO_URL } from "@/data/site";

export const Route = createFileRoute("/solutions")({
  head: () => ({
    meta: [
      {
        title: "SAAR Solutions — Who SAAR Is For",
        description:
          "How founders, freelancers, consultants, small businesses and privacy-conscious professionals use SAAR to organize records, check payments and understand their finances — offline.",
      },
      { property: "og:title", content: "SAAR Solutions — Who SAAR Is For" },
      {
        property: "og:description",
        content:
          "Scenario-led answers to a practical question: what does SAAR actually do for someone working with real invoices, receipts and bank exports?",
      },
    ],
  }),
  component: Solutions,
});

const AUDIENCES = [
  {
    n: "01",
    title: "Founders & independent developers",
    situation:
      "You run the product and the books. Software subscriptions, vendor invoices, contractor payments and project costs pile up across inboxes and folders while your actual work continues.",
    friction:
      "Monthly spend reviews mean opening five statements, matching charges to invoices from memory, and hoping nothing is duplicated.",
    workflow:
      "Import the invoices and bank exports you already have. SAAR structures them, computes your spending deterministically, and flags the charges that don't line up with any invoice.",
    outcome: "A monthly review that starts from organized records instead of a folder hunt.",
    caveat: "SAAR doesn't make payments or connect to your bank — it works over records you import.",
  },
  {
    n: "02",
    title: "Freelancers & consultants",
    situation:
      "Client invoices go out, payments come in, receipts accumulate. Reconciliation is the part of the month nobody enjoys.",
    friction:
      "“Did this client actually pay that invoice?” is a question your bank export can technically answer — after an afternoon of cross-referencing.",
    workflow:
      "Run reconciliation across your invoices and transaction exports. SAAR proposes matches by amount, vendor, currency and references, and presents anything unmatched for review.",
    outcome: "Clear view of which invoices are matched, which are pending, and which need a polite nudge.",
    caveat: "A proposed match stays a proposal until you approve it. Unmatched is not the same as unpaid.",
  },
  {
    n: "03",
    title: "Small businesses & startups",
    situation:
      "A founder-led team, plenty of activity, no bookkeeping department. Visibility comes from a spreadsheet someone maintains by hand.",
    friction:
      "Every question — “what did hosting cost this quarter?”, “are there duplicate payments?” — becomes a manual project.",
    workflow:
      "Structured records plus deterministic summaries give you period comparisons, merchant spending and anomaly reviews without adopting a full accounting system.",
    outcome: "Grounded answers to real questions, with the evidence a phone call away.",
    caveat: "SAAR is a financial workspace, not a certified accounting platform or a bookkeeping ERP.",
  },
  {
    n: "04",
    title: "Privacy-conscious professionals",
    situation:
      "Your invoices and statements are some of the most sensitive documents you own, and every general-purpose AI tool asks you to upload them.",
    friction:
      "The trade-off as usually offered: convenience in exchange for your financial records on someone else's servers.",
    workflow:
      "SAAR runs entirely on your machine — local OCR, a local language model, encrypted local storage. The air gap is verified in the project's own egress audit, not promised in a policy.",
    outcome: "AI assistance over your finances without uploading them to anyone.",
    caveat: "These are verified architectural properties — not an independent security certification, which SAAR does not claim.",
  },
] as const;

const SCENARIOS = [
  {
    n: "01",
    title: "Understanding monthly spending",
    what: "Import the month's bank statement CSV and the invoices behind it.",
    does: "Ask for a spending breakdown by merchant or period. The answer is computed by the engine over your imported records.",
    note: "The workspace can only analyze what has been imported into it.",
  },
  {
    n: "02",
    title: "Comparing invoices against payments",
    what: "Your invoice PDFs plus the matching bank export.",
    does: "Review proposed invoice–transaction matches; approve or reject each one.",
    note: "Proposed matches are candidates for your review, not automatic conclusions.",
  },
  {
    n: "03",
    title: "Investigating suspected duplicates",
    what: "Any export you suspect contains repeat charges or repeated imports.",
    does: "Anomaly detection surfaces candidate duplicates and unlinked large debits for investigation.",
    note: "Detection raises questions for review — it doesn't prove fraud.",
  },
  {
    n: "04",
    title: "Finding the evidence behind a number",
    what: "A workspace with documents and transactions already in it.",
    does: "Follow any figure to its source: the record, the extracted fields, the document itself.",
    note: "Traceability applies to records SAAR holds — not to your paper past.",
  },
  {
    n: "05",
    title: "Preparing a local summary",
    what: "A period of verified records.",
    does: "Generate a report stating period, currency, covered records and calculated figures; export to PDF or CSV.",
    note: "Exports describe what the workspace contains, and note its limitations.",
  },
] as const;

function Solutions() {
  return (
    <>
      {/* Opening */}
      <section className="border-b border-ink/12">
        <div className="mx-auto max-w-[76rem] px-5 pt-16 pb-14 md:px-8 md:pt-24 md:pb-20">
          <Eyebrow>Solutions</Eyebrow>
          <h1 className="mt-6 max-w-[18ch] font-display text-[2.75rem] leading-[1.05] tracking-[-0.015em] text-ink sm:text-6xl md:text-[4.4rem]">
            For the people whose finances live in folders.
          </h1>
          <Copy className="mt-8 max-w-[64ch]">
            This page answers one practical question: what does SAAR actually do for someone
            working with real invoices, receipts and bank exports? No productivity slogans — just
            situations, the friction in them, and the workflow SAAR offers.
          </Copy>
        </div>
      </section>

      {/* Audiences */}
      {AUDIENCES.map((a, i) => (
        <section key={a.n} className={i > 0 ? "border-t border-ink/12" : undefined}>
          <div className="mx-auto max-w-[76rem] px-5 py-16 md:px-8 md:py-20">
            <div className={`grid gap-10 lg:grid-cols-12 ${i % 2 === 1 ? "lg:[direction:rtl]" : ""}`}>
              <div className="lg:col-span-4 lg:[direction:ltr]">
                <span className="data-mono text-xs font-medium text-navy">{a.n}</span>
                <SectionTitle size="sm" className="mt-3">
                  {a.title}
                </SectionTitle>
              </div>
              <div className="grid gap-6 sm:grid-cols-2 lg:col-span-8 lg:[direction:ltr]">
                <div className="border-t-2 border-ink/15 pt-4">
                  <Annotation className="text-ink">The situation</Annotation>
                  <p className="mt-2 text-sm leading-relaxed text-ink-soft">{a.situation}</p>
                </div>
                <div className="border-t-2 border-ink/15 pt-4">
                  <Annotation className="text-ink">The friction</Annotation>
                  <p className="mt-2 text-sm leading-relaxed text-ink-soft">{a.friction}</p>
                </div>
                <div className="border-t-2 border-navy pt-4">
                  <Annotation className="text-navy">The SAAR workflow</Annotation>
                  <p className="mt-2 text-sm leading-relaxed text-ink-soft">{a.workflow}</p>
                </div>
                <div className="border-t-2 border-navy pt-4">
                  <Annotation className="text-navy">The outcome</Annotation>
                  <p className="mt-2 text-sm leading-relaxed text-ink-soft">{a.outcome}</p>
                  <p className="mt-3 text-xs leading-relaxed text-ink-faint">{a.caveat}</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* Practical scenarios */}
      <section className="border-t border-ink/12 bg-stone/45 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="max-w-2xl">
            <Eyebrow tone="muted">In practice</Eyebrow>
            <SectionTitle className="mt-5" size="sm">
              Five things people actually do with SAAR.
            </SectionTitle>
          </div>
          <ol className="mt-12 divide-y divide-ink/10 border-y border-ink/10">
            {SCENARIOS.map((s) => (
              <li key={s.n} className="grid gap-4 py-7 md:grid-cols-[3rem_1fr_1.2fr] md:gap-8">
                <span className="data-mono text-xs font-medium text-navy">{s.n}</span>
                <div>
                  <h3 className="font-display text-2xl leading-tight text-ink">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-soft">{s.what}</p>
                </div>
                <div>
                  <p className="text-sm leading-relaxed text-ink-soft">{s.does}</p>
                  <p className="mt-2 text-xs leading-relaxed text-ink-faint">{s.note}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Outcomes */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Eyebrow>Outcomes</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                What changes, realistically.
              </SectionTitle>
              <Copy className="mt-5">
                No promised percentages. Just the differences you can verify after a month of
                using the workspace.
              </Copy>
            </div>
            <ul className="grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 sm:grid-cols-2 lg:col-span-7">
              {[
                "Less manual document searching",
                "Financial records that are actually organized",
                "Discrepancies you can examine, not just worry about",
                "Clearer understanding of income and expenses",
                "Evidence one click away from every figure",
                "Sensitive records that stop being uploaded anywhere",
              ].map((o) => (
                <li key={o} className="flex items-center gap-4 bg-paper px-6 py-5 text-sm text-ink">
                  <span aria-hidden="true" className="data-mono text-navy">→</span>
                  {o}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Connection + CTA */}
      <section className="border-t border-ink/12 bg-paper-raised">
        <div className="mx-auto max-w-[76rem] px-5 py-16 md:px-8 md:py-20">
          <div className="grid gap-10 md:grid-cols-12 md:items-center">
            <div className="md:col-span-7">
              <h2 className="font-display text-3xl leading-tight text-ink md:text-4xl">
                See how it works, then run it on your own records.
              </h2>
              <div className="mt-6 flex flex-wrap gap-x-8 gap-y-3">
                <TextLink to="/how-it-works">Walk through the workflow</TextLink>
                <TextLink to="/product">Tour the product</TextLink>
              </div>
            </div>
            <div className="md:col-span-5 md:text-right">
              <GetSaar size="lg" className="md:ml-auto" />
              <p className="mt-3 text-xs text-ink-soft">
                Windows · Source &amp; build guide on{" "}
                <a href={REPO_URL} target="_blank" rel="noreferrer" className="underline decoration-ink/30 hover:text-navy">
                  GitHub
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
