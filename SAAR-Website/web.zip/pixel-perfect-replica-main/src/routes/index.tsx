import { createFileRoute, Link } from "@tanstack/react-router";
import { GetSaar, TextLink } from "@/components/actions";
import { AppFrame } from "@/components/app-frame";
import { Annotation, Copy, Eyebrow, SectionTitle } from "@/components/editorial";
import { FACTS } from "@/data/site";

import shotChat from "@/assets/light_02_chat_seed_report.asset.json";
import shotEmptyHero from "@/assets/light_03_chat_empty_hero.asset.json";
import shotDocuments from "@/assets/light_04_documents_archive.asset.json";
import shotRecon from "@/assets/light_05_reconciliation_review.asset.json";
import shotReports from "@/assets/light_06_financial_reports.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "SAAR — Offline Financial Intelligence for Windows · THE SHRIKS",
        description:
          "SAAR is a private, offline financial intelligence workspace for Windows. Invoices, receipts and bank exports stay on your machine, where exact calculations and local AI produce evidence-backed answers.",
      },
      { property: "og:title", content: "SAAR — Offline Financial Intelligence for Windows" },
      {
        property: "og:description",
        content:
          "Financial clarity, with its sources attached. An air-gapped desktop workspace where exact money math and local AI turn scattered records into evidence-backed answers.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-[76rem] px-5 pt-14 pb-16 md:px-8 md:pt-20 md:pb-24">
          <div className="grid items-end gap-14 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <Eyebrow className="rise">The Shriks — Financial Intelligence</Eyebrow>
              <h1 className="rise-late mt-6 font-display text-[2.75rem] leading-[1.04] tracking-[-0.015em] text-ink sm:text-6xl md:text-[4.4rem]">
                Financial clarity,
                <br />
                with its <em className="italic text-navy">sources</em> attached.
              </h1>
              <Copy className="rise-last mt-7 max-w-[54ch]">
                SAAR is an offline financial intelligence workspace for Windows. It brings the
                invoices, receipts and bank exports scattered across your folders into one private
                place — where exact calculations are made in code, and a local AI assistant answers
                your questions grounded in your own records.
              </Copy>
              <div className="rise-last mt-9 flex flex-wrap items-center gap-4">
                <GetSaar size="lg" />
                <Link
                  to="/product"
                  className="group inline-flex items-center gap-2 border-b border-ink/25 px-1 py-3 text-[15px] font-medium text-ink transition-colors hover:border-navy hover:text-navy"
                >
                  Explore SAAR
                  <span aria-hidden="true" className="transition-transform duration-200 group-hover:translate-x-0.5">
                    →
                  </span>
                </Link>
              </div>
              <Annotation className="rise-last mt-5">
                Windows desktop · Runs entirely on your machine · No cloud · No telemetry
              </Annotation>
            </div>

            <div className="relative lg:col-span-5">
              <div className="rise-late relative z-10 -rotate-[0.4deg]">
                <AppFrame
                  priority
                  src={shotChat.url}
                  alt="SAAR desktop: a grounded answer to a financial question, computed from the local ledger"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 z-20 hidden max-w-[16rem] -rotate-[0.4deg] rounded-md border border-navy/25 bg-navy px-4 py-3 text-paper shadow-lg sm:block">
                <Annotation className="text-[10px] text-paper/70">Answer in view</Annotation>
                <p className="data-mono mt-1 text-xs leading-snug">
                  "$3,759.50 net surplus — grounded in the local ledger, not guessed."
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Verified fact strip */}
        <div className="border-y border-ink/12 bg-paper-raised">
          <dl className="mx-auto grid max-w-[76rem] gap-px px-5 py-6 sm:grid-cols-2 md:px-8 lg:grid-cols-4">
            {FACTS.map((f) => (
              <div key={f.term} className="pr-6">
                <dt className="data-mono text-xs font-medium text-navy">{f.term}</dt>
                <dd className="mt-1.5 text-[13px] leading-snug text-ink-soft">{f.detail}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* ================= THE RECORDS PROBLEM ================= */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-6">
              <Eyebrow tone="muted">The records problem</Eyebrow>
              <SectionTitle className="mt-5">
                Your finances already exist.
                <br />
                They just don't agree
                <br />
                with each other.
              </SectionTitle>
            </div>
            <div className="lg:col-span-6 lg:pt-2">
              <Copy>
                An invoice in one folder. A receipt photo in another. A bank export that names
                vendors differently. Matching payments by hand, re-adding totals, wondering whether
                a bill was ever actually paid — and if you hand it all to a chatbot, the numbers
                sound confident and the sources are nowhere to be found.
              </Copy>
              <div className="mt-8 border border-ink/12 bg-paper-raised p-5 md:p-6">
                <Annotation>What the folder looks like today (illustrative)</Annotation>
                <ul className="data-mono mt-3 space-y-1.5 text-[12px] leading-relaxed text-ink-soft">
                  <li>invoices/gst_b2b_valid.pdf</li>
                  <li>receipts/thermal_receipt_scanned.png</li>
                  <li>bank/us_bank_statement_sep.csv</li>
                  <li>bank/us_bank_statement_oct.csv …</li>
                </ul>
                <p aria-hidden="true" className="my-3 text-center text-navy">
                  ↓
                </p>
                <Annotation>What SAAR makes of it — one reviewable record</Annotation>
                <div className="data-mono mt-3 grid grid-cols-[auto_1fr_auto] gap-x-4 gap-y-1 text-[12px] text-ink">
                  <span className="text-ink-soft">vendor</span>
                  <span>CloudHosting Corp</span>
                  <span className="text-navy">✓</span>
                  <span className="text-ink-soft">amount</span>
                  <span>$914.00 USD</span>
                  <span className="text-navy">✓</span>
                  <span className="text-ink-soft">status</span>
                  <span>proposed match — awaiting your review</span>
                  <span className="text-ink-faint">…</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= THE APPROACH ================= */}
      <section className="border-t border-ink/12 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="max-w-2xl">
            <Eyebrow>The approach</Eyebrow>
            <SectionTitle className="mt-5">
              AI helps you understand.
              <br />
              Engineering decides the numbers.
            </SectionTitle>
            <Copy className="mt-6">
              In SAAR, the language model never performs arithmetic or invents totals. Every
              financial figure is produced by a controlled operation in the Rust core — so an
              answer can always be traced back to the exact calculation and records behind it.
            </Copy>
          </div>

          <ol className="mt-14 grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                n: "01",
                t: "You ask",
                d: "A question in plain language: “What is our net operating surplus?”",
                tag: "your words",
              },
              {
                n: "02",
                t: "SAAR authorizes an operation",
                d: "The local model resolves your intent to a defined, permitted financial operation.",
                tag: "intent — not arithmetic",
              },
              {
                n: "03",
                t: "The core computes",
                d: "Deterministic Rust code runs the operation in exact minor units. The model does none of the math.",
                tag: "exact i64 math",
              },
              {
                n: "04",
                t: "You inspect the evidence",
                d: "The answer arrives with its supporting records, documents and calculations attached.",
                tag: "traceable",
              },
            ].map((s) => (
              <li key={s.n} className="flex flex-col bg-paper p-6 md:p-7">
                <div className="flex items-baseline justify-between">
                  <span className="data-mono text-xs font-medium text-navy">{s.n}</span>
                  <span className="eyebrow text-ink-faint">{s.tag}</span>
                </div>
                <h3 className="mt-6 font-display text-2xl leading-tight text-ink">{s.t}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink-soft">{s.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ================= CAPABILITIES ================= */}
      <section className="border-t border-ink/12 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="max-w-2xl">
            <Eyebrow>What SAAR does</Eyebrow>
            <SectionTitle className="mt-5">A workspace, not a chatbot.</SectionTitle>
          </div>

          {/* 1 — Organize records: text left, image right */}
          <div className="mt-16 grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <p className="data-mono text-xs font-medium text-navy">01 — Records</p>
              <h3 className="mt-3 font-display text-3xl leading-tight text-ink md:text-4xl">
                Bring your documents into one encrypted place.
              </h3>
              <Copy className="mt-5">
                Import digital invoices, scanned receipts and bank statement CSVs. SAAR validates
                and stores each file in an AES-256-GCM content-addressed vault, extracts the
                fields that matter, and keeps uncertain results clearly marked for your review.
              </Copy>
            </div>
            <div className="lg:col-span-7">
              <AppFrame
                src={shotDocuments.url}
                alt="SAAR's document archive: an ingestion pipeline and repository of encrypted financial documents"
                caption="The document repository. Every import is fingerprinted (SHA-256) and stored encrypted inside the workspace."
              />
            </div>
          </div>

          {/* 2 — Calculations: typographic, no screenshot */}
          <div className="mt-20 grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-7 lg:order-1 order-2">
              <p className="data-mono text-xs font-medium text-navy">02 — Calculations</p>
              <h3 className="mt-3 font-display text-3xl leading-tight text-ink md:text-4xl">
                Numbers computed in code, not composed by a model.
              </h3>
              <Copy className="mt-5">
                Income, expenses, cash flow, merchant spending, period comparisons — every figure
                comes from deterministic operations in the Rust core, in signed 64-bit minor
                currency units. Different currencies are never silently blended with invented
                exchange rates.
              </Copy>
              <div className="mt-7 border border-ink/12 bg-paper-raised p-5">
                <Annotation>Inside the engine (illustrative)</Annotation>
                <div className="data-mono mt-3 space-y-1.5 text-[12px] text-ink-soft">
                  <p>inflow <span className="text-ink">500000 ¢</span> — outflow <span className="text-ink">124050 ¢</span></p>
                  <p>
                    net = inflow − outflow = <span className="font-medium text-navy">375950 ¢ → $3,759.50</span>
                  </p>
                  <p className="text-ink-faint">i64 minor units · currency preserved · no floats</p>
                </div>
              </div>
            </div>
            <div className="order-1 lg:col-span-5 lg:order-2">
              <blockquote className="border-l-2 border-navy pl-6">
                <p className="font-display text-2xl italic leading-snug text-ink md:text-[1.7rem]">
                  “A language model can help you ask. It should never be trusted to total.”
                </p>
              </blockquote>
            </div>
          </div>

          {/* 3 — Reconciliation: image left, text right */}
          <div className="mt-20 grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <AppFrame
                src={shotRecon.url}
                alt="SAAR's reconciliation inbox: detected anomalies and candidate invoice-payment matches awaiting review"
                caption="The reconciliation inbox. Anomalies and proposed matches are presented as candidates for your review — never as verdicts."
              />
            </div>
            <div className="lg:col-span-5">
              <p className="data-mono text-xs font-medium text-navy">03 — Reconciliation</p>
              <h3 className="mt-3 font-display text-3xl leading-tight text-ink md:text-4xl">
                Payments checked against invoices — with you deciding.
              </h3>
              <Copy className="mt-5">
                SAAR compares invoices with bank transactions using amount, vendor, currency,
                references and date windows. It proposes matches, flags suspected duplicates and
                unlinked debits — and every proposed link stays a proposal until you approve it.
              </Copy>
            </div>
          </div>

          {/* 4 — Ask & inspect */}
          <div className="mt-20 grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <p className="data-mono text-xs font-medium text-navy">04 — Ask &amp; inspect</p>
              <h3 className="mt-3 font-display text-3xl leading-tight text-ink md:text-4xl">
                Ask in plain language. Open the evidence.
              </h3>
              <Copy className="mt-5">
                A local assistant — Qwen2.5-3B running on your own CPU — helps you explore your
                records conversationally. Answers are grounded in authorized operations, and the
                evidence inspector opens the records, documents and calculations behind any figure.
              </Copy>
              <TextLink to="/product" className="mt-7">
                See the full workspace
              </TextLink>
            </div>
            <div className="lg:col-span-7">
              <AppFrame
                src={shotEmptyHero.url}
                alt="SAAR's conversation workspace with suggested financial questions"
                caption="The conversation workspace. Suggested questions are grounded in what your workspace actually contains."
              />
            </div>
          </div>
        </div>
      </section>

      {/* ================= SHOWCASE ================= */}
      <section className="border-t border-ink/12 bg-stone/45 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-10 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-5">
              <Eyebrow tone="muted">The application</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                Real reports, from real records, on your desk.
              </SectionTitle>
              <Copy className="mt-5">
                Deterministic financial reports with provenance-audited PDF and CSV exports.
                Periods, currencies, records, calculations and their sources — in one view you can
                hand to an accountant without handing over your data.
              </Copy>
              <TextLink to="/product" className="mt-7">
                Tour the product
              </TextLink>
            </div>
            <div className="lg:col-span-7">
              <AppFrame
                src={shotReports.url}
                alt="SAAR's deterministic financial reports: inflow, outflow, net operating surplus and ledger breakdown"
                caption="Financial reports, computed from the sample workspace. Figures export as source-traceable PDF or RFC 4180 CSV."
              />
            </div>
          </div>
        </div>
      </section>

      {/* ================= PRIVACY ================= */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Eyebrow>Privacy by architecture</Eyebrow>
              <SectionTitle className="mt-5">
                Nothing leaves
                <br />
                your machine.
              </SectionTitle>
              <Copy className="mt-6">
                SAAR isn't “cloud AI with a privacy policy.” It is built to operate with no network
                connection at all — the browser layer is compiled with outbound connections
                disabled, and the whole application is routinely tested that way.
              </Copy>
              <Annotation className="mt-6">
                Verification status: passed quality gates G0–G7, documented in the project's
                verification ledger.
              </Annotation>
            </div>
            <div className="lg:col-span-7">
              <dl className="divide-y divide-ink/10 border-y border-ink/10">
                {[
                  ["Air gap", "Compiled with connect-src 'none'. Verified in a disconnected namespace: 0 WAN packets, 0 DNS lookups."],
                  ["Encrypted vaults", "AES-256-GCM archives (.saar) holding the workspace database and documents, unlocked with Argon2id-derived keys."],
                  ["Memory hygiene", "Derived keys are wiped from memory on lock — not left lying around in RAM."],
                  ["Local inference", "A quantized Qwen2.5-3B model ships with the app and runs on your CPU. Nothing is sent to any API."],
                  ["Audit trail", "Approvals, edits and rejections are recorded with before/after states and timestamps."],
                ].map(([term, detail]) => (
                  <div key={term} className="grid gap-2 py-5 sm:grid-cols-[10rem_1fr] sm:gap-8">
                    <dt className="data-mono text-xs font-medium text-navy">{term}</dt>
                    <dd className="text-sm leading-relaxed text-ink-soft">{detail}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </section>

      {/* ================= FINAL DOWNLOAD ================= */}
      <section className="bg-navy text-paper">
        <div className="mx-auto max-w-[76rem] px-5 py-20 md:px-8 md:py-28">
          <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-7">
              <Eyebrow tone="paper">Get SAAR</Eyebrow>
              <h2 className="mt-5 font-display text-[2.6rem] leading-[1.05] tracking-[-0.01em] sm:text-6xl md:text-[4.2rem]">
                Your records.
                <br />
                Your machine.
                <br />
                <em className="italic text-paper/80">Your answers.</em>
              </h2>
            </div>
            <div className="lg:col-span-5">
              <GetSaar variant="onNavy" size="lg" />
              <p className="mt-5 text-sm leading-relaxed text-paper/70">
                SAAR {""}
                <span className="data-mono">v0.1.0</span> is engineered and quality-gate verified
                for Windows. Public installer publishing is being prepared — for now, the official
                repository carries the source, the Windows build guide and the release notes.
              </p>
              <a
                href="https://github.com/THE-SHRIKS/SAAR-LokiXPiyush/blob/main/Docs/WINDOWS_BUILD_GUIDE.md"
                target="_blank"
                rel="noreferrer"
                className="link-rule mt-4 inline-block text-sm font-medium text-paper"
              >
                Read the Windows build guide →
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
