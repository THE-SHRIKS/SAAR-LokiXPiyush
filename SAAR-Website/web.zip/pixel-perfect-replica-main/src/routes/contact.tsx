import { createFileRoute, Link } from "@tanstack/react-router";
import { Eyebrow, Copy, SectionTitle, Annotation } from "@/components/editorial";
import { REPO_ISSUES_URL, REPO_URL, ORG_URL } from "@/data/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      {
        title: "Contact THE SHRIKS — SAAR",
        description:
          "Reach THE SHRIKS about SAAR: product enquiries, technical support, business and partnership discussions — through the project's verified official channels.",
      },
      { property: "og:title", content: "Contact THE SHRIKS — SAAR" },
      {
        property: "og:description",
        content:
          "Product enquiries, technical support and business discussions — through SAAR's verified official channels.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <>
      {/* Opening */}
      <section className="border-b border-ink/12">
        <div className="mx-auto max-w-[76rem] px-5 pt-16 pb-14 md:px-8 md:pt-24 md:pb-20">
          <Eyebrow>Contact</Eyebrow>
          <h1 className="mt-6 max-w-[16ch] font-display text-[2.75rem] leading-[1.05] tracking-[-0.015em] text-ink sm:text-6xl md:text-[4.4rem]">
            Talk to THE SHRIKS.
          </h1>
          <Copy className="mt-8 max-w-[64ch]">
            SAAR is built in the open, and so is communication about it. The channels below are
            the project's verified ones — we won't publish an email address or phone number we
            can't stand behind, and we won't pretend a form works when no submission service is
            configured yet.
          </Copy>
        </div>
      </section>

      {/* Verified channels */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 md:grid-cols-3">
            <a
              href={REPO_ISSUES_URL}
              target="_blank"
              rel="noreferrer"
              className="group flex flex-col bg-paper p-7 transition-colors hover:bg-paper-raised"
            >
              <Annotation className="text-navy">Primary channel</Annotation>
              <h2 className="mt-4 font-display text-2xl leading-tight text-ink">Open an issue</h2>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-soft">
                Product questions, technical support, bug reports and feature requests live on the
                official repository's issue tracker — public, searchable, and answered by the
                people building SAAR.
              </p>
              <span className="data-mono mt-6 break-all text-[11px] text-ink-soft group-hover:text-navy">
                github.com/THE-SHRIKS/SAAR-LokiXPiyush/issues →
              </span>
            </a>
            <a
              href={REPO_URL}
              target="_blank"
              rel="noreferrer"
              className="group flex flex-col bg-paper p-7 transition-colors hover:bg-paper-raised"
            >
              <Annotation className="text-navy">Technical</Annotation>
              <h2 className="mt-4 font-display text-2xl leading-tight text-ink">Read the source</h2>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-soft">
                Specifications, architecture decision records, the acceptance matrix and the
                Windows build guide are all in the repository. If your question is technical, the
                answer may already be documented.
              </p>
              <span className="data-mono mt-6 break-all text-[11px] text-ink-soft group-hover:text-navy">
                github.com/THE-SHRIKS/SAAR-LokiXPiyush →
              </span>
            </a>
            <a
              href={ORG_URL}
              target="_blank"
              rel="noreferrer"
              className="group flex flex-col bg-paper p-7 transition-colors hover:bg-paper-raised"
            >
              <Annotation className="text-navy">Business &amp; partnership</Annotation>
              <h2 className="mt-4 font-display text-2xl leading-tight text-ink">THE SHRIKS</h2>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-soft">
                Business and partnership discussions are welcome through the organization's GitHub
                profile. A public email address has not been published yet — this page will carry
                it the day that changes.
              </p>
              <span className="data-mono mt-6 break-all text-[11px] text-ink-soft group-hover:text-navy">
                github.com/THE-SHRIKS →
              </span>
            </a>
          </div>
        </div>
      </section>

      {/* What to include */}
      <section className="border-t border-ink/12 bg-stone/45 py-16 md:py-24">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Eyebrow tone="muted">Writing to us</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                A good enquiry gets a good answer.
              </SectionTitle>
              <Copy className="mt-5">
                Whichever category fits, a sentence or two of context helps: what you're working
                with, what you expected, and what happened instead.
              </Copy>
            </div>
            <dl className="grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 sm:grid-cols-2 lg:col-span-7">
              {[
                ["Product enquiries", "What you're trying to accomplish with SAAR, and what you'd like to know before installing."],
                ["Technical support", "Your Windows version, the document types involved, and what you saw versus what you expected."],
                ["Business discussions", "Who you are, what your organization does, and the shape of the collaboration you have in mind."],
                ["Partnerships", "The nature of the partnership, timelines, and the best way to continue the conversation."],
              ].map(([t, d]) => (
                <div key={t} className="bg-paper p-6">
                  <dt className="font-display text-lg text-ink">{t}</dt>
                  <dd className="mt-2 text-sm leading-relaxed text-ink-soft">{d}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      {/* Privacy note */}
      <section className="py-16 md:py-20">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="border-l-2 border-navy pl-6 md:pl-8">
            <Annotation className="text-navy">A note on privacy</Annotation>
            <Copy className="mt-3 max-w-[72ch]">
              SAAR the application processes your financial records entirely offline — that's its
              architecture, and it is verified. Contacting THE SHRIKS through this website is a
              different thing: reaching us via GitHub means your message is handled under
              GitHub's service, on GitHub's infrastructure, not inside SAAR's air gap.
            </Copy>
          </div>
          <div className="mt-12 flex flex-wrap items-center justify-between gap-6 border-t border-ink/12 pt-8">
            <p className="text-sm text-ink-soft">
              Ready to inspect the product itself?
              <Link to="/how-it-works" className="ml-2 font-medium text-navy underline decoration-navy/30 hover:decoration-navy">
                See how it works
              </Link>
            </p>
            <Link
              to="/"
              className="link-rule text-sm font-medium text-navy"
            >
              Back home →
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
