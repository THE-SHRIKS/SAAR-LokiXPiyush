import { createFileRoute, Link } from "@tanstack/react-router";
import { GetSaar, TextLink } from "@/components/actions";
import { AppFrame } from "@/components/app-frame";
import { Annotation, Copy, Eyebrow, SectionTitle } from "@/components/editorial";

import shotChat from "@/assets/light_02_chat_seed_report.asset.json";
import shotDocuments from "@/assets/light_04_documents_archive.asset.json";
import shotRecon from "@/assets/light_05_reconciliation_review.asset.json";
import shotReports from "@/assets/light_06_financial_reports.asset.json";
import shotDarkChat from "@/assets/dark_02_chat_seed_report.asset.json";
import shotDarkEvidence from "@/assets/dark_04_evidence_inspector.asset.json";

export const Route = createFileRoute("/product")({
  head: () => ({
    meta: [
      {
        title: "SAAR Product — A Private Financial Operations Workspace",
        description:
          "Explore SAAR: document import with reviewable extraction, exact minor-unit calculations, invoice reconciliation, anomaly review, a grounded local AI assistant, and an evidence inspector — all offline on Windows.",
      },
      { property: "og:title", content: "SAAR Product — A Private Financial Operations Workspace" },
      {
        property: "og:description",
        content:
          "Documents, deterministic calculations, reconciliation, evidence and local AI — one offline Windows workspace where every figure can be traced to its source.",
      },
    ],
  }),
  component: Product,
});

const WORKSPACE_AREAS = [
  ["Conversation workspace", "Ask financial questions in plain language; answers arrive grounded in your ledger."],
  ["Documents & Ingestion", "Import PDFs, scanned receipts and bank CSVs into the encrypted repository."],
  ["Reconciliation & Ledger", "Review proposed invoice–payment matches, anomalies and every ledger posting."],
  ["Financial Reports", "Deterministic summaries with source-traceable PDF and CSV exports."],
  ["Evidence inspector", "Open the records, extracted fields and calculations behind any figure."],
  ["Vault & Cryptography", "Lock, unlock, back up and restore your encrypted workspace."],
] as const;

const SPEC_ROWS = [
  ["Air gap", "Compiled with connect-src 'none'; verified in a disconnected namespace — 0 WAN packets, 0 DNS lookups."],
  ["Key derivation", "Argon2id, 64 MiB memory, 3 passes. Derived keys are zeroized from RAM on lock."],
  ["Storage", "Workspace-isolated SQLite (WAL + FTS5) inside AES-256-GCM content-addressed blob storage."],
  ["Money math", "Signed 64-bit minor currency units in the Rust core. No floating point on any financial path."],
  ["Local AI", "Quantized Qwen2.5-3B-Instruct via llama.cpp on CPU, pinned by SHA-256, constrained by GBNF grammars."],
  ["OCR", "Local RapidOCR ONNX models (DBNet + SVTR) with interactive bounding-box overlays."],
  ["Exports", "Pure-Rust PDF 1.4 vector writer and RFC 4180 CSV exporter."],
  ["Audit", "Immutable audit trail: every mutation recorded with before/after states and timestamps."],
] as const;

function Product() {
  return (
    <>
      {/* Opening */}
      <section className="border-b border-ink/12">
        <div className="mx-auto max-w-[76rem] px-5 pt-16 pb-14 md:px-8 md:pt-24 md:pb-20">
          <Eyebrow>Product</Eyebrow>
          <h1 className="mt-6 max-w-[16ch] font-display text-[2.75rem] leading-[1.05] tracking-[-0.015em] text-ink sm:text-6xl md:text-[4.4rem]">
            A private financial operations workspace.
          </h1>
          <div className="mt-8 grid gap-10 lg:grid-cols-12">
            <Copy className="lg:col-span-5">
              SAAR is one desktop application where your documents, your ledger, your calculations
              and your questions live together. Import a record and it becomes structured data.
              Ask a question and it is answered by a controlled operation over that data. Doubt a
              figure and you can open the document it came from — without leaving the app, and
              without your records ever leaving your machine.
            </Copy>
            <Copy className="lg:col-span-5 lg:col-start-8">
              The areas below are one environment, not separate products. They exist so you can
              move in a straight line: from a financial question, to the operation that answers
              it, to the record that supports the answer.
            </Copy>
          </div>
          <div className="mt-12">
            <AppFrame
              priority
              src={shotChat.url}
              alt="SAAR's conversation workspace answering a financial question from the local ledger"
              caption="A grounded answer. The assistant cites that it operated over the local SQLite ledger — the numbers were computed, not generated."
            />
          </div>
        </div>
      </section>

      {/* Workspace index */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="max-w-2xl">
            <Eyebrow tone="muted">The workspace</Eyebrow>
            <SectionTitle className="mt-5" size="sm">
              Six areas, one line of sight.
            </SectionTitle>
          </div>
          <ol className="mt-12 grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 sm:grid-cols-2 lg:grid-cols-3">
            {WORKSPACE_AREAS.map(([title, detail], i) => (
              <li key={title} className="bg-paper p-6">
                <span className="data-mono text-xs font-medium text-navy">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="mt-4 font-display text-xl leading-tight text-ink">{title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-soft">{detail}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Import & understanding */}
      <section className="border-t border-ink/12 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Eyebrow>Import &amp; understanding</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                From file to record, with review in the middle.
              </SectionTitle>
              <Copy className="mt-5">
                Digital PDFs, scanned receipts and images, and bank statement CSVs are validated,
                fingerprinted and stored encrypted on import. Local OCR and extraction identify
                merchants, dates, invoice numbers, currencies, totals and payment references.
              </Copy>
              <Copy className="mt-4">
                Extraction is deliberately review-oriented: uncertain fields stay visible and
                editable, and your corrections are captured in the audit trail. OCR is good —
                it is not assumed to be perfect.
              </Copy>
            </div>
            <div className="lg:col-span-7">
              <AppFrame
                src={shotDocuments.url}
                alt="SAAR's document archive and ingestion pipeline"
                caption="The air-gapped ingestion pipeline. Eligible files: digital PDFs, scanned images, bank statement CSVs — up to the limits shown in the interface."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Calculations */}
      <section className="border-t border-ink/12 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Eyebrow>Financial calculations</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                The model interprets. The core computes.
              </SectionTitle>
              <Copy className="mt-5">
                When you ask for monthly expenses, income, net cash flow, merchant spending or a
                period comparison, SAAR resolves your request to a defined financial operation and
                executes it in the Rust core — in signed 64-bit minor units, with overflow-proof
                arithmetic. Currencies are preserved as recorded; two currencies are never
                silently merged with an invented rate.
              </Copy>
              <blockquote className="mt-8 border-l-2 border-navy pl-6">
                <p className="font-display text-2xl italic leading-snug text-ink">
                  “$124.05 is 12,405 cents. SAAR keeps it that way end to end.”
                </p>
                <Annotation className="mt-3">Minor-unit arithmetic, from entry to export</Annotation>
              </blockquote>
            </div>
            <div className="lg:col-span-7">
              <div className="overflow-hidden rounded-md border border-ink/12 bg-paper-raised">
                <div className="border-b border-ink/10 px-5 py-3">
                  <Annotation>Monthly ledger breakdown — sample workspace (illustrative data)</Annotation>
                </div>
                <table className="data-mono w-full text-left text-[12px] text-ink">
                  <thead>
                    <tr className="border-b border-ink/10 text-ink-soft">
                      <th className="px-5 py-3 font-medium">Period</th>
                      <th className="px-5 py-3 font-medium">Transactions</th>
                      <th className="px-5 py-3 font-medium">Inflow</th>
                      <th className="px-5 py-3 font-medium">Outflow</th>
                      <th className="px-5 py-3 font-medium">Net</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="px-5 py-3">2026-09</td>
                      <td className="px-5 py-3">7</td>
                      <td className="px-5 py-3">$5,000.00</td>
                      <td className="px-5 py-3">$1,240.50</td>
                      <td className="px-5 py-3 font-medium text-navy">$3,759.50</td>
                    </tr>
                  </tbody>
                </table>
                <div className="border-t border-ink/10 px-5 py-3">
                  <Annotation>Computed in the Rust core as i64 minor units — the same figures visible in the reports view below.</Annotation>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reconciliation + anomalies */}
      <section className="border-t border-ink/12 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid items-start gap-12 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <AppFrame
                src={shotRecon.url}
                alt="SAAR's reconciliation inbox with detected anomalies and candidate link proposals"
                caption="Reconciliation review: anomalies are raised for investigation, and candidate matches await approval."
              />
            </div>
            <div className="lg:col-span-5">
              <Eyebrow>Reconciliation</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                A proposal is not a payment.
              </SectionTitle>
              <Copy className="mt-5">
                SAAR compares invoices with transactions using amount, vendor tokens, currency,
                references and date tolerance. Deterministic multi-pass matching proposes links;
                you approve, reject or investigate each one — and the decision is recorded.
              </Copy>
              <Copy className="mt-4">
                A missing transaction in an imported export is not proof that an invoice is
                unpaid. SAAR treats unmatched records as questions to resolve, not verdicts.
              </Copy>
              <div className="mt-7 border border-ink/12 bg-paper-raised p-5">
                <Annotation>Detection distinguishes</Annotation>
                <ul className="mt-3 space-y-2 text-sm text-ink-soft">
                  <li className="flex gap-3"><span className="data-mono text-xs text-navy">a</span>Repeated imports of the same file</li>
                  <li className="flex gap-3"><span className="data-mono text-xs text-navy">b</span>Separate, potentially duplicate payments</li>
                  <li className="flex gap-3"><span className="data-mono text-xs text-navy">c</span>Legitimate recurring transactions</li>
                  <li className="flex gap-3"><span className="data-mono text-xs text-navy">d</span>Incomplete or unusual records</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Local AI — navy band */}
      <section className="bg-navy text-paper">
        <div className="mx-auto max-w-[76rem] px-5 py-20 md:px-8 md:py-28">
          <div className="grid gap-12 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-5">
              <Eyebrow tone="paper">Local AI assistant</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                Grounded answers, on your own silicon.
              </SectionTitle>
              <Copy className="mt-5 text-paper/70">
                The assistant is a quantized Qwen2.5-3B model running locally via llama.cpp — no
                API, no account, no network. Its output is constrained by formal grammars, and
                claims are verified against retrieved records before you see them.
              </Copy>
              <ol className="mt-8 space-y-3">
                {[
                  "Your question, in plain language",
                  "An authorized financial operation is resolved",
                  "The deterministic core computes the result",
                  "A grounded explanation is composed — with citations",
                ].map((step, i) => (
                  <li key={step} className="flex gap-4 text-sm text-paper/85">
                    <span className="data-mono shrink-0 text-xs text-paper/50">{String(i + 1).padStart(2, "0")}</span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>
            <div className="lg:col-span-7">
              <AppFrame
                src={shotDarkChat.url}
                alt="SAAR in Midnight mode: a grounded financial answer in the conversation workspace"
                caption="Midnight mode. The answer states its grounding explicitly: local ledger, local CPU, no cloud."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Evidence */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-7 lg:order-1 order-2">
              <AppFrame
                src={shotDarkEvidence.url}
                alt="SAAR's contextual evidence inspector opened beside a conversation"
                caption="The evidence inspector opens beside the conversation, so the answer and its proof share one screen."
              />
            </div>
            <div className="lg:col-span-5 order-1 lg:order-2">
              <Eyebrow>Evidence &amp; traceability</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                Every figure keeps its receipts.
              </SectionTitle>
              <Copy className="mt-5">
                A financial claim in SAAR is connected to the records that support it — the
                extracted fields, the transaction rows, the calculation that produced the number.
                Evidence is referenced directly: citations point at invoice and transaction
                identifiers, not at vibes.
              </Copy>
              <p className="data-mono mt-6 text-[12px] leading-relaxed text-ink-soft">
                [inv:INV-88912] → CloudHosting Corp · $914.00 USD
                <br />
                [tx:…4172] → 2026-09-26 · matched pending approval
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Reports */}
      <section className="border-t border-ink/12 bg-stone/45 py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <Eyebrow tone="muted">Reports &amp; outputs</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                Summaries you can hand over.
              </SectionTitle>
              <Copy className="mt-5">
                Reports state their period, currency, the records they cover, the calculated
                figures and their sources. Export as a source-traceable vector PDF or an RFC 4180
                CSV — both written by pure-Rust exporters inside the app.
              </Copy>
              <Copy className="mt-4">
                SAAR does not invent forecasts. A report covers what your workspace actually
                contains.
              </Copy>
            </div>
            <div className="lg:col-span-7">
              <AppFrame
                src={shotReports.url}
                alt="SAAR's deterministic financial reports view"
                caption="Deterministic reports with provenance-audited PDF & CSV exports."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Architecture ledger */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-[76rem] px-5 md:px-8">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <Eyebrow>Under the hood</Eyebrow>
              <SectionTitle className="mt-5" size="sm">
                Architecture, as verified.
              </SectionTitle>
              <Copy className="mt-5">
                These are implemented characteristics, checked by the project's quality gates
                (G0–G7). The full acceptance matrix and specifications live in the repository.
              </Copy>
              <TextLink to="/how-it-works" className="mt-6">
                See it in use
              </TextLink>
            </div>
            <div className="lg:col-span-8">
              <dl className="divide-y divide-ink/10 border-y border-ink/10">
                {SPEC_ROWS.map(([term, detail]) => (
                  <div key={term} className="grid gap-2 py-4 sm:grid-cols-[9rem_1fr] sm:gap-8">
                    <dt className="data-mono text-xs font-medium text-navy">{term}</dt>
                    <dd className="text-sm leading-relaxed text-ink-soft">{detail}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>

        {/* Differentiation */}
        <div className="mx-auto mt-20 max-w-[76rem] px-5 md:px-8">
          <Eyebrow tone="muted">What makes this different</Eyebrow>
          <div className="mt-8 grid gap-px overflow-hidden rounded-md border border-ink/12 bg-ink/10 sm:grid-cols-2">
            {[
              ["Local, not cloud-dependent", "Processing happens on your hardware. There is no server to trust, no upload to regret."],
              ["Controlled calculation, not model arithmetic", "Language models interpret requests; the Rust core produces every amount."],
              ["Inspectable records, not unsupported statements", "Answers carry their sources, and the sources stay openable."],
              ["Human approval, not autonomous decisions", "Material financial actions wait for you — and every decision is audited."],
            ].map(([t, d]) => (
              <div key={t} className="bg-paper p-6 md:p-8">
                <h3 className="font-display text-xl leading-snug text-ink md:text-2xl">{t}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink-soft">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-ink/12 bg-paper-raised">
        <div className="mx-auto max-w-[76rem] px-5 py-16 md:px-8 md:py-20">
          <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
            <div>
              <h2 className="font-display text-3xl leading-tight text-ink md:text-4xl">
                See it working on your own records.
              </h2>
              <p className="mt-2 text-sm text-ink-soft">Free to inspect. Windows. Offline by design.</p>
            </div>
            <GetSaar size="lg" />
          </div>
        </div>
      </section>
    </>
  );
}
